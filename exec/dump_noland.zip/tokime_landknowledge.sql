-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: j11B207.p.ssafy.io    Database: tokime
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `landknowledge`
--

DROP TABLE IF EXISTS `landknowledge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `landknowledge` (
  `knowledge_id` bigint NOT NULL AUTO_INCREMENT,
  `knowledge_category` bigint NOT NULL,
  `knowledge_describe` varchar(255) NOT NULL,
  `knowledge_image_url` varchar(255) NOT NULL,
  `knowledge_name` varchar(255) NOT NULL,
  PRIMARY KEY (`knowledge_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `landknowledge`
--

LOCK TABLES `landknowledge` WRITE;
/*!40000 ALTER TABLE `landknowledge` DISABLE KEYS */;
INSERT INTO `landknowledge` VALUES (1,0,'토지를 구매하기 전, 구매할 수 있는 금액을 확인합니다. 대출을 받을 수 있는 상황인지, 대출을 너무 과하게 받지 않고 투자할 수 있도록 합니다.','https://cdn-icons-png.flaticon.com/128/2462/2462160.png','구매 여유자금 확인'),(2,0,'사용용도를 고려한 투자 목적을 정하고 맞춤형 투자지역을 탐색해야 합니다.','https://cdn-icons-png.flaticon.com/128/17072/17072438.png','투자 지역 고르기'),(3,0,'해당 매물에 대한 전문가의 의견을 들어보며 현장을 직접 다니며 좋은 토지를 선택합니다.','https://cdn-icons-png.flaticon.com/128/2139/2139218.png','중개업소 방문 및 현장 확인'),(4,0,'토지등기사항전부증명서, 토지대장, 토지이용계획확인서를 확인합니다.','https://cdn-icons-png.flaticon.com/128/4822/4822197.png','공부서류 확인 후 계약'),(5,0,'중도금, 잔금 등 금전적인 부분을 해결하고 소유권이전에 대한 내용을 등기합니다.','https://cdn-icons-png.flaticon.com/128/3798/3798681.png','중도금, 잔금 등 소유권이전 등기'),(6,1,'토지의 용도지역과 지구가 무엇인지 파악하는 것이 중요합니다.','https://cdn-icons-png.flaticon.com/128/7132/7132306.png','계약하는 토지 목적 확인'),(7,1,'토지에 건물을 지을 수 있는 상태로 만들기 위해 받아야 하는 허가를 말합니다. 경사도, 도로, 상하수도 등의 기준에 적합해야 합니다.','https://cdn-icons-png.flaticon.com/128/1642/1642400.png','개발 행위 허가 가능여부'),(8,1,'계약하려는 토지가 지적도상 도로에 접해있는지, 도로 폭은 최소한 4m 이상인지, 도로에 접하는 면이 2m 이상 되는지 확인해야 합니다. ','https://cdn-icons-png.flaticon.com/128/2154/2154839.png','인접도로 확인'),(9,1,'배수로가 공부상 접해있는지 파악해야 합니다. 일반 구거인지 관개수로인지 확인해야 합니다.','https://cdn-icons-png.flaticon.com/128/5755/5755873.png','배수로 확인'),(10,1,'포락으로 인한 유실이나 하천부지 점용 가능성을 확인해야 합니다.','https://cdn-icons-png.flaticon.com/128/7063/7063294.png','하천에 접한 토지의 경우'),(11,1,'지적도와 실제 토지가 일치하는지 확인해야 합니다.','https://cdn-icons-png.flaticon.com/128/12774/12774051.png','지적도 확인'),(12,1,'토지의 모양은 일반적으로 사각형이 가장 좋습니다. 땅의 성질도 중요합니다. 연약 지반인지, 암반 지반인지 등을 확인합니다.','https://cdn-icons-png.flaticon.com/128/16191/16191108.png','경사도와 토지의 모양, 땅의 성질 파악'),(13,1,'위반건축물이 있는 경우 이행강제금이 부과되는데 위반건축물의 여부를 알든, 알지 못하든 소유자가 바뀌면 새로운 소유자에게 부과됩니다.','https://cdn-icons-png.flaticon.com/128/1350/1350245.png','위반건축물 유무 확인'),(14,1,'허가구역 내에 있는 토지에 관한 소유권, 지상권을 이전 또는 설정하는 계약예약 포함을 체결하거나, 허가 받은 사항을 변경하고자 하는 자는 시의 허가를 받아야 합니다.','https://cdn-icons-png.flaticon.com/128/16196/16196254.png','토지거래허가제도'),(15,1,'도로가 접하지 못한 땅은 개발을 할 수 없습니다. 도로가 사도인지 공도인지 확인해야 합니다. 건축법상 도로인지도 확인해야 합니다.','https://cdn-icons-png.flaticon.com/128/2154/2154839.png','맹지'),(16,1,'법적으로 개발이 제한된 구역으로, 개인적인 건축이나 개발이 거의 불가능한 지역입니다.','https://cdn-icons-png.flaticon.com/128/15113/15113955.png','개발제한구역'),(17,1,'공공의 이익을 위해 지정된 산지로, 사유지로의 개발이 어렵습니다.','https://cdn-icons-png.flaticon.com/128/10236/10236796.png','공익용 산지'),(18,1,'생태계 보호를 위한 지역으로 지정된 땅으로, 개발 제한이 심합니다.','https://cdn-icons-png.flaticon.com/128/8098/8098974.png','비오톱등급의 땅'),(19,1,'축사, 퇴비공장, 무덤, 공동묘지, 쓰레기 매립지, 고물상, 화장터 등은 환경 문제로 인해 가치가 하락할 가능성이 큽니다.','https://cdn-icons-png.flaticon.com/128/4357/4357594.png','혐오시설 가까운 땅'),(20,1,'고압선 철탑이 있는 곳의 아래. 보상지 시세를 다 주지 않습니다. 고압 전선이 지나가는 땅으로, 안전 문제와 건강 위험성 때문에 피해야 합니다.','https://cdn-icons-png.flaticon.com/128/763/763398.png','선하지'),(21,1,'현재 농업이 이루어지고 있는 땅으로 농작물이 있다면 농작물을 수확한 이후에 소유권을 행사할 수 있습니다.','https://cdn-icons-png.flaticon.com/128/2979/2979777.png','경작하는 땅'),(22,1,'소음, 공해 문제로 주거 및 상업적으로 매력도가 떨어집니다.','https://cdn-icons-png.flaticon.com/128/2062/2062694.png','고속도로 인접 땅'),(23,1,'개발을 하려면 막대한 토목 비용이 드는 경우, 경제적 리스크가 큽니다.','https://cdn-icons-png.flaticon.com/128/6978/6978359.png','토목공사비 많이 드는 땅'),(24,1,'북향 또는 경사면에 위치해 있어 일조량이 부족하거나 바람이 많이 부는 등의 문제가 있는 땅입니다.','https://cdn-icons-png.flaticon.com/128/1897/1897399.png','토지의 방향'),(25,1,'주요 인프라에서 멀리 떨어진 외진 지역의 땅은 개발 및 활용성이 낮습니다.','https://cdn-icons-png.flaticon.com/128/4515/4515475.png','외진 땅'),(26,1,'여러 명이 소유권을 나누고 있는 땅으로, 법적 분쟁 및 복잡한 절차가 문제될 수 있습니다.','https://cdn-icons-png.flaticon.com/128/17523/17523563.png','지분거래의 땅');
/*!40000 ALTER TABLE `landknowledge` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-10 23:43:52
