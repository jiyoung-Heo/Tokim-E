-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: j11B207.p.ssafy.io    Database: tokime
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `checklist`
--

DROP TABLE IF EXISTS `checklist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `checklist` (
  `checklist_id` int NOT NULL AUTO_INCREMENT,
  `content` varchar(255) NOT NULL,
  PRIMARY KEY (`checklist_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `checklist`
--

LOCK TABLES `checklist` WRITE;
/*!40000 ALTER TABLE `checklist` DISABLE KEYS */;
INSERT INTO `checklist` VALUES (0,'직접 현장을 방문하지 않고 지인 또는 텔레마케터에게 권유받지는 않으셨나요?'),(1,'개발제한구역, 상수원보호구역, 군사시설보호구역, 보전산지, 농업진흥구역 등 개발이 어려운 토지는 아닌가요?'),(2,'높은 고도에 위치하거나, 경사도가 심한 임야 등의 토지를 거래하지는 않나요?'),(3,'구체적인 개발계획이 없거나 판매 토지와 전혀 상관없는 개발계획이지는 않나요?'),(4,'개발호재가 있는 인근지역에 개발이 곤란하거나 경제적 가치가 없는 토지거래는 아닌가요?'),(5,'가치가 낮은 임야, 전, 답 등을 공유지분으로 거래하지는 않나요?'),(6,'선입금 강요 및 계약 전까지 지번 등 해당 물건지의 정확한 정보를 알려주었나요?'),(7,'매수금액이 1천만원 ~ 5천만원 정도에 해당하지는 않나요?'),(8,'주변의 시세 및 공시지가 대비 월등히 높은 가격으로 거래하지는 않나요?'),(9,'판매자가 \"OO경매\", \"OO에셋\", OO옥션\", \"OO농업법인\" 등의 상호를 사용하지는 않나요?'),(10,'토지 등기부등본 상 소유주가 아닌 법인이 매매하거나 소유자이더라도 단기간 소유 토지거래는 아닌가요?');
/*!40000 ALTER TABLE `checklist` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-10 23:59:14
