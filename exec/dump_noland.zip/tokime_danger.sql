-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: j11B207.p.ssafy.io    Database: tokime
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `danger`
--

DROP TABLE IF EXISTS `danger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `danger` (
  `danger_id` bigint NOT NULL AUTO_INCREMENT,
  `danger_content` varchar(1500) NOT NULL,
  `danger_title` varchar(255) NOT NULL,
  `lat` double NOT NULL,
  `lng` double NOT NULL,
  PRIMARY KEY (`danger_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `danger`
--

LOCK TABLES `danger` WRITE;
/*!40000 ALTER TABLE `danger` DISABLE KEYS */;
INSERT INTO `danger` VALUES (1,'한밭대 근처 땅이라고 하는데,\n무조건 개발 호재라고 땅을\n안보고 사도 괜찮다고 막 추천해요','사기가 의심됩니다',36.3479351,127.2975736),(2,'땅을 판매하시는 분이 이 땅이\n현재 수자원 보호구역 이라서 오히려 가치가 낮게 평가 되어있다고 얼른 투자하라고 꼬드겨요 ','수자원 보호구역 투자?',36.3445971,127.2956187),(3,'한밭대 근처에 있는 계룡산 땅을 추천해주는 사람이 있어요. 누가 봐도 절벽인데 곧 도로가 들어설거라고 하네요. 완전 사기꾼 아닌가요?!','급경사의 땅을 추천하는 사기꾼',36.3538259,127.2877115),(4,'한밭대 앞에 이케아가 들어온다고 그 예정지에 있는 자기 땅을 싸게 팔겠다고 하는 사람이 있어요! 절대 속지 마세요..!!','한밭대 개발 가짜뉴스',36.3509206,127.2968353),(5,'덕명동 주변 지역에 개발 계획이 수립되었다고 땅을 구매하라 꼬드기는 사람들이 많은데 실제 땅을 보면 도로에 접해있지 않은 땅도 팔고있습니다!! 진짜 조심해서 투자하셔야해요. 저도 직접 가보지 않았으면 큰일 날 뻔 했습니다','덕명동 투자 조심!!',36.3550893,127.3039801),(6,'진짜 최악의 사기꾼이 있어요. 한밭대 앞쪽의 땅인데 50명한테 지분을 나눠서 팔려고 한 거 있죠? ','50명과 함께하는 투자',36.3589756,127.3017663);
/*!40000 ALTER TABLE `danger` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-10 23:59:15
