-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: j11B207.p.ssafy.io    Database: tokime
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `quiz_correct`
--

DROP TABLE IF EXISTS `quiz_correct`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quiz_correct` (
  `quiz_correct_id` bigint NOT NULL AUTO_INCREMENT,
  `correct_answer` varchar(255) NOT NULL,
  `quiz_id` bigint NOT NULL,
  PRIMARY KEY (`quiz_correct_id`),
  KEY `FK6p42lehsbotqhu7f973gxlge` (`quiz_id`),
  CONSTRAINT `FK6p42lehsbotqhu7f973gxlge` FOREIGN KEY (`quiz_id`) REFERENCES `quiz` (`quiz_id`)
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quiz_correct`
--

LOCK TABLES `quiz_correct` WRITE;
/*!40000 ALTER TABLE `quiz_correct` DISABLE KEYS */;
INSERT INTO `quiz_correct` VALUES (1,'건축물 건립',1),(2,'건물 건축을 위한 허가',2),(3,'경사도와 도로 기준',3),(4,'상하수도 기준 적합성',4),(5,'유실의 가능성',5),(6,'토지의 용도',6),(7,'지나친 비와 강한 유량',7),(8,'지목과 지적현상',8),(9,'건축물 건립',9),(10,'건물 건축을 위한 허가',10),(11,'경사도와 도로 기준',11),(12,'상하수도 기준 적합성',12),(13,'유실의 가능성',13),(14,'토지의 용도',14),(15,'지나친 비와 강한 유량',15),(16,'지목과 지적현상',16),(17,'관계 기관에 신고',17),(18,'지목 변화 가능성',18),(19,'토지 소유권의 명확화',19),(20,'사각형',20),(21,'연약 지반 여부',21),(22,'쉽게 변형되는 땅',22),(23,'색상 측정',23),(24,'4m',24),(25,'2m',25),(26,'법정 도로인지 비법정 도로인지 여부',26),(27,'지적도에 등록된 도로',27),(28,'배수로의 종류',28),(29,'물의 용도',29),(30,'농작물에 물을 공급하기 위함',30),(31,'시정명령 이행',31),(32,'최대 1,000만 원',32),(33,'시청 또는 구청의 건축과',33),(34,'시민의 안전을 위해',34),(35,'새로운 소유자에게 부과된다',35),(36,'재산 몰수',36),(37,'토지 등기부 등본',37),(38,'시장, 군수 또는 구청장에게 다시 허가를 받아야 함',38),(39,'허가구역 외의 토지 거래',39),(40,'토지의 안전한 거래 촉진',40),(41,'개인 소유로 인해 관리가 용이',41),(42,'대중교통이 없는 지역',42),(43,'사도는 특정 개인의 소유, 공도는 공공의 소유',43),(44,'도로가 없는 땅',44),(45,'환경 보호 및 자연 보존',45),(46,'개인 주택 건축',46),(47,'시가화 지역',47),(48,'생태계 보호',48),(49,'산지관리법',49),(50,'미세먼지 제거',50),(51,'대규모 아파트 건설',51),(52,'생태계 보호를 위한 지역',52),(53,'생물 다양성을 유지하기 위해',53),(54,'환경 보호 법률',54),(55,'모든 형태의 개발',55),(56,'환경 문제',56),(57,'공원',57),(58,'주거 환경 악화',58),(59,'건강 문제 증가',59),(60,'시세의 일부만 지급된다',60),(61,'건강 및 안전 문제',61),(62,'낮아진다',62),(63,'경작하는 땅',63),(64,'경제적 이유',64),(65,'소유권 법규',65),(66,'수확 후',66),(67,'소음 및 공해 문제',67),(68,'소음과 공해 문제',68),(69,'소음 때문에 고객 유입 감소',69),(70,'대중교통이 잘 발달된 지역',70),(71,'지형의 복잡성',71),(72,'고산지대',72),(73,'적정 규모의 개발',73),(74,'높은 지하수위',74),(75,'태양의 경로가 북쪽으로 이동하기 때문입니다',75),(76,'비가 많이 오면 토사가 유실될 수 있다',76),(77,'창문의 크기',77),(78,'토양의 균형이 무너질 수 있음',78),(79,'외부 기업의 투자 유도',79),(80,'인프라 부족',80),(81,'농업용',81),(82,'인프라에서 멀리 떨어진 지역',82),(83,'다른 소유권자의 동의 여부',83),(84,'여러 명이 소유권을 나누어 가진다',84),(85,'모든 소유자와 계약서를 작성한다',85),(86,'모든 소유자의 동의를 받아야 한다',86);
/*!40000 ALTER TABLE `quiz_correct` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-10 23:59:15
